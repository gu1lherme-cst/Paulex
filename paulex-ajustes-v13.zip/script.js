/* ============================================================
   Paulex Armarinho — script.js (lógica do site)
   Os produtos e categorias ficam em produtos.js
   ============================================================ */

const ORDERS = [];

const ICON_BOX = icon('<path d="M4 8l8-4 8 4v9l-8 4-8-4V8z"/><path d="M4 8l8 4 8-4M12 12v9"/>');
const ICON_CHEV = '<svg class="chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m9 5 7 7-7 7"/></svg>';
const ICON_CART = icon('<path d="M6 7h12l1 13H5L6 7z"/><path d="M9 9V6a3 3 0 0 1 6 0v3"/>');

/* ---------- Estado ---------- */
const CUSTOMER_AREA_AVAILABLE =
  typeof CUSTOMER_AREA_ENABLED !== "undefined" && CUSTOMER_AREA_ENABLED;

let cart = JSON.parse(localStorage.getItem("paulex_cart") || "{}");
let favs = new Set(JSON.parse(localStorage.getItem("paulex_favs") || "[]"));
let logged = CUSTOMER_AREA_AVAILABLE && localStorage.getItem("paulex_logged") === "1";
let currentProduct = null;
let productQty = 1;
let currentListKind = "";
let currentSort = "relevancia";

if (!CUSTOMER_AREA_AVAILABLE) {
  localStorage.removeItem("paulex_logged");
  localStorage.removeItem("paulex_user");
}

const $ = (sel) => document.querySelector(sel);
const money = (v) =>
  v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
const escapeHTML = (v) =>
  String(v).replace(/[&<>"']/g, (ch) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
  }[ch]));

function track(event, data = {}) {
  window.dataLayer = window.dataLayer || [];
  window.dataLayer.push({ event, ...data });
}

/* ---------- Preço com desconto por quantidade ---------- */
function unitPrice(p, qty) {
  if (!p.tiers) return p.preco;
  const tier = p.tiers.find((t) => qty >= t.de && qty <= t.ate);
  return tier ? tier.preco : p.preco;
}

/* ============================================================
   ROTEAMENTO — URLs reais (#/produto/caneta-bic), com suporte
   ao botão voltar/avançar do navegador e links compartilháveis
   ============================================================ */
function showScreen(id) {
  document.querySelectorAll(".screen").forEach((s) => s.classList.remove("active"));
  const el = document.getElementById("screen-" + id);
  el.classList.add("active");
  window.scrollTo(0, 0);

  if (id === "club") {
    $("#club-points").hidden = !CUSTOMER_AREA_AVAILABLE || !logged;
    $("#club-login-cta").hidden = CUSTOMER_AREA_AVAILABLE && logged;
  }
  if (id === "home") renderRecent();
  if (id === "carrinho") renderCart();

  const nav = el.dataset.nav;
  document.querySelectorAll("[data-go]").forEach((b) =>
    b.classList.toggle("active", b.dataset.go === nav)
  );
}

function setRoute(r) {
  if (location.hash === "#" + r) route();
  else location.hash = r;
}

function go(id) { setRoute("/" + id); }
function openList(kind) { setRoute("/lista/" + encodeURIComponent(kind)); }
function openProduct(id) { setRoute("/produto/" + id); }

function back() {
  if (history.length > 1 && location.hash) history.back();
  else go("home");
}

function route() {
  const h = location.hash.replace(/^#\/?/, "");
  const [base, param] = h.split("/");

  if (!base) return showScreen("home");
  if (base === "produto" && PRODUCTS.some((p) => p.id === param)) return renderProduct(param);
  if (base === "lista") return renderList(decodeURIComponent(param || "maisvendidos"));

  const telas = ["home", "categorias", "carrinho", "club", "login", "conta", "pedidos", "enderecos", "privacidade", "termos"];
  if (telas.includes(base)) {
    let id = base;
    // Áreas pessoais exigem login (evita exibir dados de demonstração)
    if (["conta", "pedidos", "enderecos"].includes(id) && (!CUSTOMER_AREA_AVAILABLE || !logged)) id = "login";
    return showScreen(id);
  }
  showScreen("home");
}
window.addEventListener("hashchange", route);

document.querySelectorAll("[data-go]").forEach((b) =>
  b.addEventListener("click", () => go(b.dataset.go))
);

function openWhatsApp(texto) {
  const msg = texto || "Olá, Paulex! Vim pelo site e gostaria de um atendimento.";
  track("whatsapp_click");
  const win = window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(msg)}`, "_blank", "noopener");
  if (win) win.opener = null;
}

/* ---------- Render: categorias ---------- */
function renderCategories() {
  $("#cat-row").innerHTML = CATEGORIES.map(
    (c) => `
    <button class="cat-chip" onclick="openList('cat:${c.id}')">
      <span>${c.icon}</span>${c.nome}
    </button>`
  ).join("");

  $("#cat-list").innerHTML = CATEGORIES.map(
    (c) => `
    <button class="cat-card" onclick="openList('cat:${c.id}')">
      <span class="cat-ico">${c.icon}</span>
      <div><strong>${c.nome}</strong><small>${c.desc}</small></div>
      ${ICON_CHEV}
    </button>`
  ).join("");

  $("#foot-cats").innerHTML = CATEGORIES.map(
    (c) => `<button onclick="openList('cat:${c.id}')">${c.nome}</button>`
  ).join("");
}

/* ---------- Render: cards de produto ---------- */
function productMedia(p) {
  if (p.imagem) {
    return `<img src="${p.imagem}" alt="${escapeHTML(p.nome)}" loading="lazy" decoding="async">`;
  }
  return p.art;
}

function productCard(p) {
  const tag = p.promo
    ? `<span class="tag">OFERTA</span>`
    : p.novidade
    ? `<span class="tag new">NOVO</span>`
    : "";
  const old = p.precoAntigo ? `<span class="old">${money(p.precoAntigo)}</span>` : "";
  return `
    <div class="card" onclick="openProduct('${p.id}')" onkeydown="cardKey(event,'${p.id}')" role="button" tabindex="0">
      <div class="ph">${tag}${productMedia(p)}</div>
      <div class="info">
        <span class="name">${p.nome}</span>
        ${old}
        <span class="price${p.precoAntigo ? " red" : ""}">${money(p.preco)}</span>
        <button class="add" aria-label="Adicionar ${p.nome} ao carrinho"
          onclick="event.stopPropagation(); quickAdd('${p.id}')">${ICON_CART} Adicionar</button>
      </div>
    </div>`;
}

function cardKey(e, id) {
  if (e.key === "Enter" || e.key === " ") {
    e.preventDefault();
    openProduct(id);
  }
}

function renderHome() {
  $("#home-grid").innerHTML =
    PRODUCTS.filter((p) => p.maisVendido).map(productCard).join("");
  $("#promo-grid").innerHTML =
    PRODUCTS.filter((p) => p.promo).slice(0, 4).map(productCard).join("");
}

/* ---------- Busca com sugestões instantâneas ---------- */
const searchInput = $("#search-input");
const suggest = $("#suggest");

function renderSuggest(term) {
  const q = term.trim().toLowerCase();
  if (q.length < 2) { suggest.hidden = true; return; }
  const hits = PRODUCTS.filter((p) => productMatches(p, q)).slice(0, 6);
  if (!hits.length) {
    suggest.innerHTML = `<div class="sug-empty">Nenhum produto encontrado para "${escapeHTML(term)}".</div>`;
  } else {
    suggest.innerHTML = hits.map((p) => `
      <button class="sug" onclick="suggestGo('${p.id}')">
        <span class="sug-art">${productMedia(p)}</span>
        <span class="sug-name">${p.nome}</span>
        <span class="sug-price">${money(p.preco)}</span>
      </button>`).join("");
  }
  suggest.hidden = false;
}

function suggestGo(id) {
  suggest.hidden = true;
  searchInput.value = "";
  openProduct(id);
}

searchInput.addEventListener("input", (e) => renderSuggest(e.target.value));
searchInput.addEventListener("focus", (e) => renderSuggest(e.target.value));
searchInput.addEventListener("keydown", (e) => {
  if (e.key === "Escape") suggest.hidden = true;
  if (e.key === "Enter") {
    const q = e.target.value.trim();
    if (q.length >= 2) {
      suggest.hidden = true;
      track("search", { search_term: q });
      openList("busca:" + q);
    }
  }
});
document.addEventListener("click", (e) => {
  if (!e.target.closest(".search-wrap")) suggest.hidden = true;
});

/* ---------- Lista (categoria / ofertas / favoritos) ---------- */
function productMatches(p, q) {
  const cat = CATEGORIES.find((c) => c.id === p.cat);
  return [p.nome, p.desc, p.unidade, cat && cat.nome]
    .filter(Boolean)
    .some((value) => value.toLowerCase().includes(q));
}

function listFor(kind) {
  if (kind.startsWith("cat:")) {
    const cat = CATEGORIES.find((c) => c.id === kind.slice(4));
    return { title: cat ? cat.nome : "Produtos", list: PRODUCTS.filter((p) => p.cat === (cat && cat.id)) };
  }
  if (kind.startsWith("busca:")) {
    const termo = kind.slice(6).trim();
    const q = termo.toLowerCase();
    return { title: `Busca: ${termo}`, list: PRODUCTS.filter((p) => productMatches(p, q)) };
  }
  if (kind === "promocoes" || kind === "ofertas")
    return { title: "Promoções", list: PRODUCTS.filter((p) => p.promo) };
  if (kind === "novidades")
    return { title: "Novidades", list: PRODUCTS.filter((p) => p.novidade) };
  if (kind === "favoritos")
    return { title: "Favoritos", list: PRODUCTS.filter((p) => favs.has(p.id)) };
  return { title: "Mais vendidos", list: PRODUCTS.filter((p) => p.maisVendido) };
}

function sortedList(list) {
  const l = [...list];
  if (currentSort === "menor") l.sort((a, b) => a.preco - b.preco);
  if (currentSort === "maior") l.sort((a, b) => b.preco - a.preco);
  if (currentSort === "avaliados") l.sort((a, b) => b.avaliacoes - a.avaliacoes);
  return l;
}

function renderList(kind) {
  if (kind !== currentListKind) currentSort = "relevancia";
  currentListKind = kind;

  const { title, list } = listFor(kind);
  $("#list-title").textContent = title;
  $("#list-grid").innerHTML = sortedList(list).map(productCard).join("");
  $("#list-empty").hidden = list.length > 0;
  $("#sort-row").hidden = list.length < 2;
  $("#sort-row").querySelectorAll(".sort").forEach((b) =>
    b.classList.toggle("active", b.dataset.sort === currentSort)
  );
  showScreen("list");
}

function sortBy(btn) {
  currentSort = btn.dataset.sort;
  renderList(currentListKind);
}

/* ---------- Favoritos ---------- */
function toggleFav() {
  const id = currentProduct.id;
  if (favs.has(id)) { favs.delete(id); toast("Removido dos favoritos"); }
  else { favs.add(id); toast("Salvo nos favoritos ❤"); }
  localStorage.setItem("paulex_favs", JSON.stringify([...favs]));
  updateFavBtn();
}

function updateFavBtn() {
  $("#p-fav").classList.toggle("fav-on", !!currentProduct && favs.has(currentProduct.id));
}

/* ---------- Produto ---------- */
function renderProduct(id) {
  currentProduct = PRODUCTS.find((p) => p.id === id);
  productQty = 1;
  const p = currentProduct;

  $("#p-photo").innerHTML = productMedia(p);
  $("#p-name").textContent = p.nome;
  $("#p-unit").textContent = p.unidade;
  const full = Math.round(p.rating);
  $("#p-stars").innerHTML =
    "★".repeat(full) + "☆".repeat(5 - full) +
    ` <small>${p.rating.toFixed(1)} (${p.avaliacoes.toLocaleString("pt-BR")} avaliações)</small>`;
  $("#p-price").innerHTML =
    money(p.preco) + (p.precoAntigo ? `<small>${money(p.precoAntigo)}</small>` : "");
  $("#p-price").classList.toggle("red", !!p.precoAntigo);
  $("#p-stock").innerHTML =
    `● Em estoque <span>· ${p.estoque} unidades disponíveis</span>`;
  $("#p-desc").textContent = p.desc;

  $("#p-specs-body").innerHTML = p.specs
    .map(([k, v]) => `<div class="spec"><dt>${k}</dt><dd>${v}</dd></div>`)
    .join("");

  if (p.tiers) {
    $("#p-tiers").hidden = false;
    $("#p-tiers-body").innerHTML = p.tiers.map((t) => {
      const faixa = t.ate === Infinity ? `${t.de}+ unidades` : `${t.de} a ${t.ate} unidades`;
      return `<tr><td>${faixa}</td><td>${money(t.preco)}</td><td class="off">${t.off || ""}</td></tr>`;
    }).join("");
  } else {
    $("#p-tiers").hidden = true;
  }

  // Produtos relacionados (mesma categoria)
  const rel = PRODUCTS.filter((x) => x.cat === p.cat && x.id !== p.id).slice(0, 4);
  $("#p-related-wrap").hidden = rel.length === 0;
  $("#p-related").innerHTML = rel.map(productCard).join("");

  renderReviews(p);
  updateFavBtn();
  updateProductTotal();
  pushRecent(p.id);
  showScreen("produto");
}

/* ---------- Vistos recentemente ---------- */
function pushRecent(id) {
  const rec = JSON.parse(localStorage.getItem("paulex_recent") || "[]").filter((x) => x !== id);
  rec.unshift(id);
  localStorage.setItem("paulex_recent", JSON.stringify(rec.slice(0, 8)));
}

function renderRecent() {
  const rec = JSON.parse(localStorage.getItem("paulex_recent") || "[]")
    .map((id) => PRODUCTS.find((p) => p.id === id))
    .filter(Boolean);
  $("#recent-section").hidden = rec.length === 0;
  $("#recent-row").innerHTML = rec.map((p) => `
    <button class="mini-card" onclick="openProduct('${p.id}')">
      <span class="mini-art">${productMedia(p)}</span>
      <span class="mini-name">${p.nome}</span>
      <span class="mini-price">${money(p.preco)}</span>
    </button>`).join("");
}

/* ---------- Resumo de avaliações ---------- */
function renderReviews(p) {
  const full = Math.round(p.rating);
  $("#p-rev-score").textContent = p.rating.toFixed(1).replace(".", ",");
  $("#p-rev-stars").textContent = "★".repeat(full) + "☆".repeat(5 - full);
  $("#p-rev-count").textContent =
    `${p.avaliacoes.toLocaleString("pt-BR")} avaliações`;

  // distribuição aproximada a partir da nota média
  const r = p.rating;
  const pesos = [
    Math.max(0.02, (r - 3) / 2),
    Math.max(0.05, (r - 2.5) / 4),
    Math.max(0.005, 0.12 - (r - 4) * 0.06),
    Math.max(0.005, 0.06 - (r - 4) * 0.04),
    Math.max(0.005, 0.04 - (r - 4) * 0.03),
  ];
  const total = pesos.reduce((a, b) => a + b, 0);
  $("#p-rev-bars").innerHTML = pesos.map((w, i) => {
    const pct = Math.round((w / total) * 100);
    return `
      <div class="rev-row">
        <span>${5 - i}★</span>
        <div class="rev-bar"><span style="width:${pct}%"></span></div>
        <small>${pct}%</small>
      </div>`;
  }).join("");
}

function pQty(delta) {
  productQty = Math.max(1, Math.min(currentProduct.estoque, productQty + delta));
  updateProductTotal();
}

function updateProductTotal() {
  const p = currentProduct;
  const unit = unitPrice(p, productQty);
  const total = unit * productQty;
  const economia = (p.preco - unit) * productQty;

  $("#p-qty").textContent = productQty;
  $("#p-total-label").textContent =
    `Total (${productQty} ${productQty > 1 ? "unidades" : "unidade"})`;
  $("#p-total").textContent = money(total);
  $("#p-save").hidden = economia <= 0.005;
  $("#p-save").textContent = `Economize ${money(economia)}`;
}

/* ---------- Carrinho ---------- */
function saveCart() {
  localStorage.setItem("paulex_cart", JSON.stringify(cart));
  updateBadges();
}

function updateBadges() {
  const count = Object.values(cart).reduce((a, b) => a + b, 0);
  document.querySelectorAll(".cart-badge").forEach((b) => {
    b.textContent = count;
    b.style.display = count ? "" : "none";
  });
}

function setCartQty(id, qty) {
  const p = PRODUCTS.find((x) => x.id === id);
  if (!p) return false;
  const next = Math.max(0, Math.min(p.estoque, qty));
  if (next <= 0) delete cart[id];
  else cart[id] = next;
  return next === qty;
}

function quickAdd(id) {
  const ok = setCartQty(id, (cart[id] || 0) + 1);
  saveCart();
  track("add_to_cart", { item_id: id, quantity: 1 });
  toast(ok ? "Adicionado ao carrinho ✓" : "Estoque máximo no carrinho");
}

function addToCart() {
  const id = currentProduct.id;
  const ok = setCartQty(id, (cart[id] || 0) + productQty);
  saveCart();
  track("add_to_cart", { item_id: id, quantity: productQty });
  toast(ok ? "Adicionado ao carrinho ✓" : "Quantidade ajustada ao estoque");
}

function buyNow() {
  addToCart();
  go("carrinho");
}

function cartQty(id, delta) {
  const ok = setCartQty(id, (cart[id] || 0) + delta);
  saveCart();
  if (!ok && delta > 0) toast("Estoque máximo no carrinho");
  renderCart();
}

function clearCart() {
  if (!Object.keys(cart).length) return;
  if (confirm("Esvaziar o carrinho?")) {
    cart = {};
    saveCart();
    renderCart();
  }
}

/* ---------- Cupom de desconto ---------- */
let cupom = localStorage.getItem("paulex_cupom") || "";
if (!CUPONS[cupom]) cupom = "";

function applyCupom() {
  const cod = $("#coupon-input").value.trim().toUpperCase();
  if (!cod) return;
  if (!CUPONS[cod]) {
    toast("Cupom inválido ou expirado");
    return;
  }
  cupom = cod;
  localStorage.setItem("paulex_cupom", cupom);
  toast(`Cupom ${cod} aplicado!`);
  $("#coupon-input").value = "";
  renderCart();
}

function removeCupom() {
  cupom = "";
  localStorage.removeItem("paulex_cupom");
  renderCart();
}

function cartTotals() {
  let cheio = 0, total = 0, itens = 0;
  for (const [id, qty] of Object.entries(cart)) {
    const p = PRODUCTS.find((x) => x.id === id);
    if (!p) continue;
    cheio += p.preco * qty;
    total += unitPrice(p, qty) * qty;
    itens += qty;
  }
  const cupomVal = CUPONS[cupom] ? total * (CUPONS[cupom].desconto / 100) : 0;
  return { cheio, total: total - cupomVal, desconto: cheio - total, cupomVal, itens };
}

function renderCart() {
  const wrap = $("#cart-items");
  const entries = Object.entries(cart).filter(([id]) => PRODUCTS.some((p) => p.id === id));
  const vazio = entries.length === 0;

  $("#cart-empty").hidden = !vazio;
  $("#cart-summary").style.display = vazio ? "none" : "";

  wrap.innerHTML = entries.map(([id, qty]) => {
    const p = PRODUCTS.find((x) => x.id === id);
    const unit = unitPrice(p, qty);
    return `
      <div class="cart-item">
        <div class="ph">${productMedia(p)}</div>
        <div class="info">
          <strong>${p.nome}</strong>
          <small>${qty} ${qty > 1 ? "unidades" : "unidade"} · ${money(unit)} cada</small>
        </div>
        <div class="stepper">
          <button onclick="cartQty('${id}',-1)" aria-label="Diminuir">−</button>
          <output>${qty}</output>
          <button onclick="cartQty('${id}',1)" aria-label="Aumentar">+</button>
        </div>
        <div class="line-price">${money(unit * qty)}</div>
      </div>`;
  }).join("");

  if (!vazio) {
    const t = cartTotals();
    $("#cart-subtotal-label").textContent =
      `Subtotal (${t.itens} ${t.itens > 1 ? "itens" : "item"})`;
    $("#cart-subtotal").textContent = money(t.cheio);
    $("#cart-discount-row").style.display = t.desconto > 0.005 ? "" : "none";
    $("#cart-discount").textContent = "-" + money(t.desconto);
    $("#cart-total").textContent = money(t.total);

    const temCupom = !!CUPONS[cupom];
    $("#coupon-form").hidden = temCupom;
    $("#cart-coupon-row").hidden = !temCupom;
    if (temCupom) {
      $("#cart-coupon-label").innerHTML =
        `Cupom <strong>${cupom}</strong> (${CUPONS[cupom].descricao}) ` +
        `<button class="coupon-remove" onclick="removeCupom()" aria-label="Remover cupom">remover</button>`;
      $("#cart-coupon").textContent = "-" + money(t.cupomVal);
    }

    const gratis = t.total >= FRETE_GRATIS_MIN;
    const falta = FRETE_GRATIS_MIN - t.total;
    const msg = $("#ship-msg");
    const fill = $("#ship-fill");
    msg.textContent = gratis
      ? "Você ganhou frete grátis!"
      : `Faltam ${money(falta)} para o frete grátis`;
    msg.classList.toggle("done", gratis);
    fill.classList.toggle("done", gratis);
    fill.style.width = Math.min(100, (t.total / FRETE_GRATIS_MIN) * 100) + "%";

    const frete = $("#cart-frete");
    frete.textContent = gratis ? "Grátis" : "A calcular";
    frete.className = gratis ? "green" : "muted";
  }

  // Continue comprando: sugestões fora do carrinho
  const sugestoes = PRODUCTS
    .filter((p) => !cart[p.id])
    .sort((a, b) => (b.maisVendido === true) - (a.maisVendido === true) || b.avaliacoes - a.avaliacoes)
    .slice(0, 8);
  $("#cart-suggest").hidden = vazio || sugestoes.length === 0;
  $("#cart-suggest-row").innerHTML = sugestoes.map((p) => `
    <button class="mini-card" onclick="openProduct('${p.id}')">
      <span class="mini-art">${productMedia(p)}</span>
      <span class="mini-name">${p.nome}</span>
      <span class="mini-price">${money(p.preco)}</span>
      <span class="mini-add" role="button" aria-label="Adicionar ${p.nome}"
        onclick="event.stopPropagation(); quickAdd('${p.id}'); renderCart()">+</span>
    </button>`).join("");
}

function cartMessage() {
  const linhas = Object.entries(cart).map(([id, qty]) => {
    const p = PRODUCTS.find((x) => x.id === id);
    if (!p) return null;
    return `• ${qty}x ${p.nome} — ${money(unitPrice(p, qty) * qty)}`;
  }).filter(Boolean);
  const t = cartTotals();
  const cupomLinha = CUPONS[cupom]
    ? `\nCupom ${cupom} (${CUPONS[cupom].descricao}): -${money(t.cupomVal)}`
    : "";
  return `Olá, Paulex! Quero fazer um pedido:\n\n${linhas.join("\n")}${cupomLinha}\n\nTotal: ${money(t.total)}`;
}

function checkoutWhatsApp() {
  if (!Object.keys(cart).length) return toast("Seu carrinho está vazio");
  track("begin_checkout", { value: cartTotals().total, currency: "BRL" });
  openWhatsApp(cartMessage());
}

/* ---------- Pedidos ---------- */
function renderOrders(filtro = "todos") {
  const map = { andamento: ["transporte"], entregues: ["entregue"], cancelados: ["cancelado"] };
  const list = filtro === "todos"
    ? ORDERS
    : ORDERS.filter((o) => map[filtro].includes(o.status));

  $("#orders").innerHTML = list.map((o) => `
    <div class="order">
      <span class="o-ico">${ICON_BOX}</span>
      <div class="o-main">
        <strong>Pedido #${o.numero}</strong>
        <small>${o.data}</small>
      </div>
      <div class="o-side">
        <span class="status ${o.status}">${o.rotulo}</span>
        <strong>${money(o.total)}</strong>
        <button class="link">Ver detalhes ›</button>
      </div>
    </div>`).join("");
  $("#orders-empty").hidden = list.length > 0;
}

function orderTab(btn, filtro) {
  $("#order-tabs").querySelectorAll(".tab").forEach((t) => t.classList.remove("active"));
  btn.classList.add("active");
  renderOrders(filtro);
}

/* ---------- Login ---------- */
function loginTab(btn, qual) {
  $("#login-tabs").querySelectorAll(".tab").forEach((t) => t.classList.remove("active"));
  btn.classList.add("active");
  $("#form-entrar").hidden = qual !== "entrar";
  $("#form-cadastrar").hidden = qual !== "cadastrar";
}

function doLogin(e) {
  e.preventDefault();
  if (!CUSTOMER_AREA_AVAILABLE) {
    toast("Área de conta em implantação. Use o WhatsApp por enquanto.");
    return;
  }
  logged = true;
  localStorage.setItem("paulex_logged", "1");
  toast("Bem-vindo à Paulex!");
  renderUser();
  setRoute("/conta");
}

function logout() {
  logged = false;
  localStorage.removeItem("paulex_logged");
  localStorage.removeItem("paulex_user");
  toast("Você saiu da sua conta");
  renderUser();
  setRoute("/login");
}

/* ---------- Login com Google (Google Identity Services) ----------
   Só é ativado quando GOOGLE_CLIENT_ID está preenchido em produtos.js */
function initGoogle() {
  if (!CUSTOMER_AREA_AVAILABLE || typeof GOOGLE_CLIENT_ID === "undefined" || !GOOGLE_CLIENT_ID) return;
  const s = document.createElement("script");
  s.src = "https://accounts.google.com/gsi/client";
  s.async = true;
  s.defer = true;
  s.onload = () => {
    google.accounts.id.initialize({
      client_id: GOOGLE_CLIENT_ID,
      callback: onGoogleCredential,
    });
    const slot = $("#google-btn-slot");
    slot.hidden = false;
    $("#or-row").hidden = false;
    google.accounts.id.renderButton(slot, {
      theme: "outline",
      size: "large",
      shape: "pill",
      text: "signin_with",
      locale: "pt-BR",
      width: 300,
    });
  };
  document.head.appendChild(s);
}

function onGoogleCredential(resp) {
  try {
    // decodifica o payload do JWT (base64url -> UTF-8)
    const b64 = resp.credential.split(".")[1].replace(/-/g, "+").replace(/_/g, "/");
    const json = decodeURIComponent(
      Array.prototype.map
        .call(atob(b64), (c) => "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2))
        .join("")
    );
    const dados = JSON.parse(json);
    localStorage.setItem("paulex_user", JSON.stringify({ nome: dados.name, email: dados.email }));
  } catch (_) { /* segue com login genérico */ }
  logged = true;
  localStorage.setItem("paulex_logged", "1");
  renderUser();
  const u = JSON.parse(localStorage.getItem("paulex_user") || "null");
  toast(u ? `Bem-vindo, ${u.nome.split(" ")[0]}!` : "Bem-vindo à Paulex!");
  setRoute("/conta");
}

function renderUser() {
  const u = JSON.parse(localStorage.getItem("paulex_user") || "null");
  $("#account-name").textContent = u ? `Olá, ${u.nome.split(" ")[0]}!` : "Olá, cliente Paulex!";
  $("#account-sub").textContent = u ? u.email : "Cliente Paulex Club · Prata";
}

/* ---------- Toast ---------- */
let toastTimer;
function toast(msg) {
  const el = $("#toast");
  el.textContent = msg;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 2200);
}

/* ---------- Revelação suave ao rolar ---------- */
if (!matchMedia("(prefers-reduced-motion: reduce)").matches && "IntersectionObserver" in window) {
  const obs = new IntersectionObserver((entries) => {
    entries.forEach((e) => {
      if (e.isIntersecting) { e.target.classList.add("in"); obs.unobserve(e.target); }
    });
  }, { threshold: 0.12 });
  document.querySelectorAll(".section, .trust, .footer").forEach((el) => {
    el.classList.add("reveal");
    obs.observe(el);
  });
}

/* ---------- Init ---------- */
renderCategories();
renderHome();
renderCart();
renderOrders();
updateBadges();
renderUser();
initGoogle();
route();

// Aplicativo instalável (PWA)
if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("sw.js").catch(() => {});
}

setTimeout(() => $("#splash").classList.add("hide"), 900);
